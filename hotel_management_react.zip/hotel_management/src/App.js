import React from "react";
import "./App.css";

export default function App() {
  return (
    <div className="app">
      {/* Navbar */}
      <header className="navbar">
        <h1 className="logo">HotelEase</h1>
        <nav>
          <a href="#">Home</a>
          <a href="#">Rooms</a>
          <a href="#">Booking</a>
          <a href="#">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <h2>Welcome to HotelEase</h2>
        <p>Luxury and comfort at your fingertips</p>
        <button className="book-btn">Book Now</button>
      </section>

      {/* Features Section */}
      <section className="features">
        <div className="card">
          <h3>🏨 Comfortable Rooms</h3>
          <p>Spacious, clean, and fully equipped rooms designed for your comfort.</p>
        </div>
        <div className="card">
          <h3>🍽️ Fine Dining</h3>
          <p>Enjoy world-class cuisine prepared by our expert chefs.</p>
        </div>
        <div className="card">
          <h3>🛎️ 24/7 Service</h3>
          <p>Our staff is always available to make your stay hassle-free.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>© 2025 HotelEase. All Rights Reserved.</p>
      </footer>
    </div>
  );
}
